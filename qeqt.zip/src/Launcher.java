import util.Core;

public class Launcher {
//test
    public static void main(String[] args) {
        Core.launch();
    }
}
