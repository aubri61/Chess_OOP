# Chess with Swing

## Summary

- This is term project of CSI2012(2019 Fall) of Yonsei University(YSU).
- Check this [document](http://bit.ly/OOP-project-20192) for more information.